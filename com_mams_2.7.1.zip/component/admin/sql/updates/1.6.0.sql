ALTER TABLE  `#__mams_articles` ADD  `ordering` INT NOT NULL;
ALTER TABLE  `#__mams_secs` ADD  `ordering` INT NOT NULL;
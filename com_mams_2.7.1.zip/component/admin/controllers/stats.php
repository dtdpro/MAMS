<?php
// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

// import Joomla controlleradmin library
jimport('joomla.application.component.controlleradmin');

class MAMSControllerStats extends JControllerAdmin
{



}